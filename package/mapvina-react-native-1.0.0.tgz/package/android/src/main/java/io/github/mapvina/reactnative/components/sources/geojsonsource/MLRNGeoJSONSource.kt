package io.github.mapvina.reactnative.components.sources.geojsonsource

import android.content.Context
import com.facebook.react.bridge.WritableArray
import com.facebook.react.bridge.WritableMap
import com.google.gson.JsonObject
import io.github.mapvina.android.style.expressions.Expression
import io.github.mapvina.android.style.sources.GeoJsonOptions
import io.github.mapvina.android.style.sources.GeoJsonSource
import io.github.mapvina.geojson.Feature
import io.github.mapvina.geojson.FeatureCollection
import io.github.mapvina.geojson.Point
import io.github.mapvina.reactnative.components.mapview.MLRNMapView
import io.github.mapvina.reactnative.components.sources.MLRNPressableSource
import io.github.mapvina.reactnative.utils.GeoJSONUtils
import java.net.URI

class MLRNGeoJSONSource(
    context: Context,
) : MLRNPressableSource<GeoJsonSource>(context) {
    private var uri: URI? = null
    private var geoJson: String? = null

    private var maxZoom: Int? = null
    private var buffer: Int? = null
    private var tolerance: Double? = null
    private var lineMetrics: Boolean? = null

    private var cluster: Boolean? = null
    private var clusterRadius: Int? = null
    private var clusterMinPoints: Int? = null
    private var clusterMaxZoom: Int? = null
    private var clusterProperties: MutableList<MutableMap.MutableEntry<String, ClusterPropertyEntry>>? =
        null

    override fun addToMap(mapView: MLRNMapView) {
        // Wait for style before adding the source to the map
        mapView.mapVinaMap!!.getStyle {
            super@MLRNGeoJSONSource.addToMap(mapView)
        }
    }

    override fun makeSource(): GeoJsonSource {
        val options = this.options

        if (geoJson != null) {
            return GeoJsonSource(mID, geoJson, options)
        }

        return GeoJsonSource(mID, uri!!, options)
    }

    fun setURI(url: URI) {
        uri = url

        if (source != null && mMapView != null && !mMapView!!.isDestroyed) {
            source!!.setUri(uri!!)
        }
    }

    fun setGeoJson(geoJson: String?) {
        this.geoJson = geoJson

        if (source != null && mMapView != null && !mMapView!!.isDestroyed) {
            source!!.setGeoJson(geoJson!!)
        }
    }

    fun setMaxZoom(value: Int?) {
        this.maxZoom = value
    }

    fun setBuffer(value: Int?) {
        this.buffer = value
    }

    fun setTolerance(value: Double?) {
        this.tolerance = value
    }

    fun setLineMetrics(lineMetrics: Boolean) {
        this.lineMetrics = lineMetrics
    }

    fun setCluster(cluster: Boolean) {
        this.cluster = cluster
    }

    fun setClusterRadius(clusterRadius: Int?) {
        this.clusterRadius = clusterRadius
    }

    fun setClusterMinPoints(clusterMinPoints: Int?) {
        this.clusterMinPoints = clusterMinPoints
    }

    fun setClusterMaxZoom(clusterMaxZoom: Int?) {
        this.clusterMaxZoom = clusterMaxZoom
    }

    fun setClusterProperties(clusterProperties: MutableList<MutableMap.MutableEntry<String, ClusterPropertyEntry>>?) {
        this.clusterProperties = clusterProperties
    }

    private val options: GeoJsonOptions
        get() {
            val options = GeoJsonOptions()

            if (cluster != null) {
                options.withCluster(cluster!!)
            }

            if (clusterRadius != null) {
                options.withClusterRadius(clusterRadius!!)
            }

            if (clusterMinPoints != null) {
                options.withClusterMinPoints(clusterMinPoints!!)
            }

            if (clusterMaxZoom != null) {
                options.withClusterMaxZoom(clusterMaxZoom!!)
            }

            if (clusterProperties != null) {
                for (entry in clusterProperties) {
                    val property: ClusterPropertyEntry = entry.value

                    options.withClusterProperty(entry.key, property.operator, property.mapping)
                }
            }

            if (maxZoom != null) {
                options.withMaxZoom(maxZoom!!)
            }

            if (buffer != null) {
                options.withBuffer(buffer!!)
            }

            if (tolerance != null) {
                options.withTolerance(tolerance!!.toFloat())
            }

            if (lineMetrics != null) {
                options.withLineMetrics(lineMetrics!!)
            }

            return options
        }

    fun getData(filter: Expression?): WritableMap {
        if (source == null) {
            throw IllegalStateException("Source is not yet loaded")
        }

        val features: List<Feature> = source!!.querySourceFeatures(filter)

        return GeoJSONUtils.fromFeatureCollection(
            FeatureCollection.fromFeatures(features),
        )
    }

    fun getClusterExpansionZoom(clusterId: Int): Int {
        if (source == null) {
            throw IllegalStateException("Source is not yet loaded")
        }

        val zoom = source!!.getClusterExpansionZoom(createClusterFeature(clusterId))

        return zoom
    }

    fun getClusterLeaves(
        clusterId: Int,
        limit: Int,
        offset: Int,
    ): WritableArray {
        if (source == null) {
            throw IllegalStateException("Source is not yet loaded")
        }

        val features =
            source!!.getClusterLeaves(
                createClusterFeature(clusterId),
                limit.toLong(),
                offset.toLong(),
            )

        return GeoJSONUtils.fromFeatureList(features.features()?.toList()!!)
    }

    fun getClusterChildren(clusterId: Int): WritableArray {
        if (source == null) {
            throw IllegalStateException("Source is not yet loaded")
        }

        val leaves = source!!.getClusterChildren(createClusterFeature(clusterId))

        return GeoJSONUtils.fromFeatureList(leaves.features()!!)
    }

    private fun createClusterFeature(clusterId: Int): Feature {
        val properties = JsonObject()
        properties.addProperty("cluster_id", clusterId)

        return Feature.fromGeometry(
            Point.fromLngLat(0.0, 0.0),
            properties,
        )
    }
}
