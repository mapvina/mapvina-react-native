package io.github.mapvina.reactnative.components.annotations.callout

import android.content.Context
import com.facebook.react.views.view.ReactViewGroup

class MLRNCallout(
    context: Context,
) : ReactViewGroup(context)
