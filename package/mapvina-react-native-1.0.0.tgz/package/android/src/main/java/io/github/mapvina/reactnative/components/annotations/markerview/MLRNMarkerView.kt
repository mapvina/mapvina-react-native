package io.github.mapvina.reactnative.components.annotations.markerview

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PointF
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.facebook.react.bridge.ReactContext
import com.facebook.react.uimanager.UIManagerHelper
import io.github.mapvina.android.geometry.LatLng
import io.github.mapvina.geojson.Point
import io.github.mapvina.reactnative.components.AbstractMapFeature
import io.github.mapvina.reactnative.components.mapview.MLRNMapView
import io.github.mapvina.reactnative.events.PointAnnotationEvent
import io.github.mapvina.reactnative.utils.GeoJSONUtils

@SuppressLint("ViewConstructor")
class MLRNMarkerView(
    context: Context,
) : AbstractMapFeature(context),
    View.OnLayoutChangeListener {
    private var mMapView: MLRNMapView? = null
    private var mChildView: View? = null
    private var mWrapperView: MLRNMarkerViewContent? = null
    private var mMarkerViewManager: MarkerViewManager? = null
    private var mMarkerInfo: MarkerViewManager.MarkerInfo? = null
    private var mCoordinate: Point? = null
    private var mAnchor: FloatArray? = null
    private var mOffset: FloatArray? = null
    private var mAddedToMap = false
    private var mLastWidth = 0
    private var mLastHeight = 0
    private var mLastZIndex: Float? = null
    private var markerId: String? = null

    private val surfaceId: Int
        get() {
            val reactContext = context as ReactContext
            return UIManagerHelper.getSurfaceId(reactContext)
        }

    private fun ViewGroup.disableClipping() {
        clipChildren = false
        clipToPadding = false
        clipToOutline = false
    }

    override fun addView(
        childView: View,
        childPosition: Int,
    ) {
        if (childPosition != 0) return

        mChildView = childView
        childView.addOnLayoutChangeListener(this)

        val offscreenContainer = mMapView?.offscreenAnnotationViewContainer()
        offscreenContainer?.disableClipping()
        offscreenContainer?.addView(childView)
    }

    override fun removeView(view: View?) {
        if (view == mChildView) {
            removeChildView()
        }
    }

    override fun removeViewAt(index: Int) {
        if (index == 0 && mChildView != null) {
            removeChildView()
        }
    }

    private fun removeChildView() {
        mChildView?.removeOnLayoutChangeListener(this)
        (mChildView?.parent as? ViewGroup)?.removeView(mChildView)
        mChildView = null
    }

    override fun getChildCount(): Int = if (mChildView != null) 1 else 0

    override fun getChildAt(index: Int): View? = if (index == 0) mChildView else null

    fun setLngLat(lngLat: DoubleArray?) {
        if (lngLat == null || lngLat.size < 2) return
        val point = Point.fromLngLat(lngLat[0], lngLat[1])
        mCoordinate = point
        val latLng = GeoJSONUtils.toLatLng(point)
        if (latLng != null && mMarkerInfo != null && mMarkerViewManager != null) {
            mMarkerViewManager!!.updateMarkerCoordinate(mMarkerInfo!!, latLng)
        }
    }

    fun setAnchor(
        x: Float,
        y: Float,
    ) {
        mAnchor = floatArrayOf(x, y)
        if (mMarkerInfo != null && mMarkerViewManager != null) {
            mMarkerViewManager!!.updateMarkerAnchor(mMarkerInfo!!, x, y)
        }
    }

    fun setOffset(
        x: Float,
        y: Float,
    ) {
        mOffset = floatArrayOf(x, y)
        val scale = resources.displayMetrics.density
        val pixelOffsetX = x * scale
        val pixelOffsetY = y * scale
        if (mMarkerInfo != null && mMarkerViewManager != null) {
            mMarkerViewManager!!.updateMarkerOffset(mMarkerInfo!!, pixelOffsetX, pixelOffsetY)
        }
    }

    fun updateZIndex(zIndex: Float) {
        mLastZIndex = zIndex
        mWrapperView?.translationZ = zIndex
    }

    fun setId(id: String) {
        markerId = id
    }

    fun onPress(
        latLng: LatLng,
        screenPos: PointF,
    ) {
        val event =
            PointAnnotationEvent(
                surfaceId,
                id,
                "onPress",
                markerId,
                latLng,
                screenPos,
            )
        mMapView?.eventDispatcher?.dispatchEvent(event)
    }

    override fun addToMap(mapView: MLRNMapView) {
        mMapView = mapView
        if (mChildView != null && !mChildView!!.isAttachedToWindow) {
            val offscreenContainer = mMapView?.offscreenAnnotationViewContainer()
            offscreenContainer?.disableClipping()
            offscreenContainer?.addView(mChildView)
        }
        tryAddToMarkerViewManager()
    }

    private fun tryAddToMarkerViewManager() {
        if (mAddedToMap || mMapView == null || mChildView == null) return
        if (mChildView!!.width == 0 || mChildView!!.height == 0) return

        mAddedToMap = true

        mMapView?.getMapAsync { mapVinaMap ->
            val latLng = GeoJSONUtils.toLatLng(mCoordinate)
            mMarkerViewManager = mMapView?.getMarkerViewManager(mapVinaMap)

            if (latLng != null && mChildView != null && mMarkerViewManager != null) {
                mMapView?.offscreenAnnotationViewContainer()?.removeView(mChildView)

                mWrapperView =
                    MLRNMarkerViewContent(context).apply {
                        layoutParams =
                            FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.WRAP_CONTENT,
                                FrameLayout.LayoutParams.WRAP_CONTENT,
                            )
                        addView(mChildView)
                    }
                mWrapperView!!.setLayerType(LAYER_TYPE_HARDWARE, null)

                mLastZIndex?.let { zIndex ->
                    mWrapperView!!.translationZ = zIndex
                }

                val scale = resources.displayMetrics.density
                val pixelOffsetX = (mOffset?.get(0) ?: 0f) * scale
                val pixelOffsetY = (mOffset?.get(1) ?: 0f) * scale

                mMarkerInfo =
                    mMarkerViewManager!!.addMarker(
                        view = mWrapperView!!,
                        markerView = this@MLRNMarkerView,
                        latLng = latLng,
                        anchorX = mAnchor?.get(0) ?: 0f,
                        anchorY = mAnchor?.get(1) ?: 0f,
                        offsetX = pixelOffsetX,
                        offsetY = pixelOffsetY,
                    )
            }
        }
    }

    override fun removeFromMap(mapView: MLRNMapView) {
        if (mMarkerInfo != null && mMarkerViewManager != null) {
            mMarkerViewManager!!.removeMarker(mMarkerInfo!!)
            mMarkerInfo = null
            mMarkerViewManager = null
        }
        mChildView?.removeOnLayoutChangeListener(this)
        mWrapperView?.removeAllViews()
        mWrapperView = null
        if (mChildView != null && !mAddedToMap) {
            mMapView?.offscreenAnnotationViewContainer()?.removeView(mChildView)
        }
        mAddedToMap = false
    }

    override fun onLayoutChange(
        v: View,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int,
        oldLeft: Int,
        oldTop: Int,
        oldRight: Int,
        oldBottom: Int,
    ) {
        if (left == 0 && top == 0 && right == 0 && bottom == 0) return

        val width = right - left
        val height = bottom - top

        if (!mAddedToMap) {
            tryAddToMarkerViewManager()
            return
        }

        if (width == mLastWidth && height == mLastHeight) return

        mLastWidth = width
        mLastHeight = height
        mChildView?.layoutParams?.let { params ->
            params.width = width
            params.height = height
        }
        mMarkerViewManager?.updateMarkers()
    }
}
