package io.github.mapvina.reactnative.events

import android.graphics.PointF
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap
import com.facebook.react.uimanager.events.Event
import io.github.mapvina.android.geometry.LatLng
import io.github.mapvina.reactnative.utils.GeoJSONUtils

open class MapPressEvent(
    surfaceId: Int,
    viewId: Int,
    private val internalEventName: String,
    private val latLng: LatLng,
    private val screenPoint: PointF,
) : Event<MapPressEvent>(surfaceId, viewId) {
    override fun getEventName() = internalEventName

    override fun getEventData(): WritableMap =
        Arguments.createMap().apply {
            putArray("lngLat", GeoJSONUtils.fromLatLng(latLng))
            putArray(
                "point",
                Arguments.createArray().apply {
                    pushDouble(screenPoint.x.toDouble())
                    pushDouble(screenPoint.y.toDouble())
                },
            )
        }
}
