#import <React/RCTViewComponentView.h>
#import <UIKit/UIKit.h>

#import <React/RCTUIManager.h>
#import <React/RCTViewComponentView.h>

NS_ASSUME_NONNULL_BEGIN

@interface MLRNMapViewComponentView : RCTViewComponentView

@end

NS_ASSUME_NONNULL_END
