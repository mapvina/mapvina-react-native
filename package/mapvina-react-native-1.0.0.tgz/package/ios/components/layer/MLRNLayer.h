#import <UIKit/UIKit.h>

@class MLRNMapView;

#import <MapVina/MapVina.h>

typedef NS_ENUM(NSInteger, MLRNLayerType) {
  MLRNLayerTypeBackground,
  MLRNLayerTypeCircle,
  MLRNLayerTypeColorRelief,
  MLRNLayerTypeFill,
  MLRNLayerTypeFillExtrusion,
  MLRNLayerTypeHeatmap,
  MLRNLayerTypeHillshade,
  MLRNLayerTypeLine,
  MLRNLayerTypeRaster,
  MLRNLayerTypeSymbol,
};

@interface MLRNLayer : UIView

@property (nonatomic, strong, nullable) MLNStyleLayer *styleLayer;
@property (nonatomic, strong, nullable) MLNStyle *style;
@property (nonatomic, weak, nullable) MLRNMapView *map;
@property (nonatomic, strong, nullable) NSDictionary *reactStyle;
@property (nonatomic, strong, nullable) NSArray *filter;

@property (nonatomic, copy, nullable) NSString *id;
@property (nonatomic, assign) MLRNLayerType layerType;
@property (nonatomic, copy, nullable) NSString *sourceID;
@property (nonatomic, copy, nullable) NSString *sourceLayerID;

@property (nonatomic, copy, nullable) NSString *aboveLayerID;
@property (nonatomic, copy, nullable) NSString *belowLayerID;
@property (nonatomic, copy, nullable) NSNumber *layerIndex;

@property (nonatomic, copy, nullable) NSNumber *maxZoomLevel;
@property (nonatomic, copy, nullable) NSNumber *minZoomLevel;

- (void)addToMap:(nonnull MLRNMapView *)map style:(nonnull MLNStyle *)style;
- (void)addedToMap;
- (void)removeFromMap:(nonnull MLNStyle *)style;
- (nullable MLNStyleLayer *)makeLayer:(nonnull MLNStyle *)style;
- (void)addStyles;
- (void)insertAbove:(nonnull NSString *)layer;
- (void)insertBelow:(nonnull NSString *)layer;
- (void)insertAtIndex:(NSUInteger)index;
- (void)setZoomBounds;

- (BOOL)isAddedToMap;

- (nullable MLNSource *)layerWithSourceIDInStyle:(nonnull MLNStyle *)style;

@end
