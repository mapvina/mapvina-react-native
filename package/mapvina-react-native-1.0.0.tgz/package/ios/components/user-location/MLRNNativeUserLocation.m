#import "MLRNNativeUserLocation.h"
#import "CameraStop.h"
#import "CameraUpdateQueue.h"
#import "MLRNEvent.h"
#import "MLRNEventTypes.h"
#import "MLRNLocation.h"
#import "MLRNLocationManager.h"
#import "MLRNUtils.h"

@implementation MLRNNativeUserLocation {
}

- (void)setMap:(MLRNMapView *)map {
  if (map == nil && _map) {
    _map.useNativeUserLocationAnnotationView = NO;
    _map.showsUserLocation = NO;
    _map.showsUserHeadingIndicator = NO;
  } else if (map) {
    map.useNativeUserLocationAnnotationView = YES;
    // Toggle off/on showsUserLocation in order for MapVina Native to invalidate the
    // current (hidden) user location annotation view. See also: HiddenUserLocationAnnotationView
    map.showsUserLocation = NO;
    map.showsUserLocation = YES;
    map.showsUserHeadingIndicator = self.showsUserHeadingIndicator;
  }

  _map = map;
}

- (void)setShowsUserHeadingIndicator:(BOOL)showsUserHeadingIndicator {
  _showsUserHeadingIndicator = showsUserHeadingIndicator;

  if (_map) {
    _map.showsUserHeadingIndicator = showsUserHeadingIndicator;
  }
}

@end
