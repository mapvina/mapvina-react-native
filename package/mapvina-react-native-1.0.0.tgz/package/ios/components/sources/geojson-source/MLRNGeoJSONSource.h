#import "MLRNSource.h"

#import <MapVina/MapVina.h>

@interface MLRNGeoJSONSource : MLRNSource

@property (nonatomic, copy, nullable) NSString *url;
@property (nonatomic, copy, nullable) NSString *shape;

@property (nonatomic, strong, nullable) NSNumber *cluster;
@property (nonatomic, strong, nullable) NSNumber *clusterRadius;
@property (nonatomic, strong, nullable) NSNumber *clusterMinPoints;
@property (nonatomic, strong, nullable) NSNumber *clusterMaxZoomLevel;
@property (nonatomic, strong, nullable)
    NSDictionary<NSString *, NSArray<NSExpression *> *> *clusterProperties;

@property (nonatomic, strong, nullable) NSNumber *maxZoomLevel;
@property (nonatomic, strong, nullable) NSNumber *buffer;
@property (nonatomic, strong, nullable) NSNumber *tolerance;
@property (nonatomic, strong, nullable) NSNumber *lineMetrics;

- (void)setReactData:(nonnull NSString *)data;

- (nonnull NSArray<id<MLNFeature>> *)featuresMatchingPredicate:(nullable NSPredicate *)predicate;
- (nonnull NSArray<id<MLNFeature>> *)getClusterLeaves:(nonnull MLNPointFeatureCluster *)cluster
                                               number:(NSUInteger)number
                                               offset:(NSUInteger)offset;
- (nonnull NSArray<id<MLNFeature>> *)getClusterChildren:(nonnull MLNPointFeatureCluster *)cluster;

- (double)getClusterExpansionZoom:(nonnull MLNPointFeatureCluster *)cluster;

@end
