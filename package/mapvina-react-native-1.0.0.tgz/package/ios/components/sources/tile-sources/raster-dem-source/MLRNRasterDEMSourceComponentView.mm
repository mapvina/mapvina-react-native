#import "MLRNRasterDEMSourceComponentView.h"

#import <react/renderer/components/MapVinaReactNativeSpec/ComponentDescriptors.h>
#import <react/renderer/components/MapVinaReactNativeSpec/EventEmitters.h>
#import <react/renderer/components/MapVinaReactNativeSpec/Props.h>
#import <react/renderer/components/MapVinaReactNativeSpec/RCTComponentViewHelpers.h>

#import "RCTFabricComponentsPlugins.h"

#import <MapVina/MapVina.h>
#import <React/RCTConversions.h>
#import "MLRNRasterDEMSource.h"

using namespace facebook::react;

// MARK: - MLRNRasterDEMSourceComponentView

@interface MLRNRasterDEMSourceComponentView () <RCTMLRNRasterDEMSourceViewProtocol>

@end

@implementation MLRNRasterDEMSourceComponentView {
  MLRNRasterDEMSource *_view;
}

- (instancetype)initWithFrame:(CGRect)frame {
  if (self = [super initWithFrame:frame]) {
    static const auto defaultProps = std::make_shared<const MLRNRasterDEMSourceProps>();
    _props = defaultProps;
    [self prepareView];
  }

  return self;
}

- (void)prepareView {
  _view = [[MLRNRasterDEMSource alloc] init];
  self.contentView = _view;
}

- (MLRNRasterDEMSource *)rasterDEMSource {
  return _view;
}

#pragma mark - RCTComponentViewProtocol

+ (ComponentDescriptorProvider)componentDescriptorProvider {
  return concreteComponentDescriptorProvider<MLRNRasterDEMSourceComponentDescriptor>();
}

- (void)updateProps:(const Props::Shared &)props oldProps:(const Props::Shared &)oldProps {
  const auto &oldViewProps = *std::static_pointer_cast<const MLRNRasterDEMSourceProps>(_props);
  const auto &newViewProps = *std::static_pointer_cast<const MLRNRasterDEMSourceProps>(props);

  if (oldViewProps.id != newViewProps.id) {
    _view.id = RCTNSStringFromString(newViewProps.id);
  }

  if (oldViewProps.url != newViewProps.url) {
    _view.url = RCTNSStringFromStringNilIfEmpty(newViewProps.url);
  }

  if (oldViewProps.tiles != newViewProps.tiles) {
    if (newViewProps.tiles.size() > 0) {
      NSMutableArray *tiles = [NSMutableArray arrayWithCapacity:newViewProps.tiles.size()];
      for (const auto &tile : newViewProps.tiles) {
        [tiles addObject:RCTNSStringFromString(tile)];
      }
      _view.tileUrlTemplates = tiles;
    } else {
      _view.tileUrlTemplates = nil;
    }
  }

  if (oldViewProps.minzoom != newViewProps.minzoom) {
    _view.minZoomLevel = newViewProps.minzoom >= 0 ? @(newViewProps.minzoom) : nil;
  }

  if (oldViewProps.maxzoom != newViewProps.maxzoom) {
    _view.maxZoomLevel = newViewProps.maxzoom >= 0 ? @(newViewProps.maxzoom) : nil;
  }

  if (oldViewProps.attribution != newViewProps.attribution) {
    _view.attribution = RCTNSStringFromStringNilIfEmpty(newViewProps.attribution);
  }

  if (oldViewProps.tileSize != newViewProps.tileSize) {
    _view.tileSize = newViewProps.tileSize >= 0 ? @(newViewProps.tileSize) : nil;
  }

  if (oldViewProps.encoding != newViewProps.encoding) {
    switch (newViewProps.encoding) {
      case MLRNRasterDEMSourceEncoding::Terrarium:
        _view.encoding = @"terrarium";
        break;
      case MLRNRasterDEMSourceEncoding::Mapbox:
      default:
        _view.encoding = @"mapbox";
        break;
    }
  }

  [super updateProps:props oldProps:oldProps];
}

- (void)mountChildComponentView:(UIView<RCTComponentViewProtocol> *)childComponentView
                          index:(NSInteger)index {
  if ([childComponentView isKindOfClass:[RCTViewComponentView class]] &&
      ((RCTViewComponentView *)childComponentView).contentView) {
    [_view insertReactSubview:(id<RCTComponent>)((RCTViewComponentView *)childComponentView)
                                  .contentView
                      atIndex:index];
  }
  [super mountChildComponentView:childComponentView index:index];
}

- (void)unmountChildComponentView:(UIView<RCTComponentViewProtocol> *)childComponentView
                            index:(NSInteger)index {
  if ([childComponentView isKindOfClass:[RCTViewComponentView class]] &&
      ((RCTViewComponentView *)childComponentView).contentView) {
    [_view removeReactSubview:(id<RCTComponent>)((RCTViewComponentView *)childComponentView)
                                  .contentView];
  }
  [super unmountChildComponentView:childComponentView index:index];
}

Class<RCTComponentViewProtocol> MLRNRasterDEMSourceCls(void) {
  return MLRNRasterDEMSourceComponentView.class;
}

@end
