import { type CodegenTypes, type HostComponent, type ViewProps } from "react-native";
import type { UnsafeMixed } from "../../../types/codegen/UnsafeMixed";
type NativeAnchor = {
    x?: CodegenTypes.WithDefault<CodegenTypes.Double, 0.5>;
    y?: CodegenTypes.WithDefault<CodegenTypes.Double, 0.5>;
};
type NativeOffset = {
    x: CodegenTypes.Double;
    y: CodegenTypes.Double;
};
type NativeAnnotationEvent = {
    id: string;
    lngLat: UnsafeMixed<[
        longitude: CodegenTypes.Double,
        latitude: CodegenTypes.Double
    ]>;
    point: UnsafeMixed<[x: CodegenTypes.Double, y: CodegenTypes.Double]>;
};
export interface NativeProps extends ViewProps {
    id: string;
    title?: string;
    snippet?: string;
    selected?: CodegenTypes.WithDefault<boolean, false>;
    draggable?: CodegenTypes.WithDefault<boolean, false>;
    lngLat: UnsafeMixed<[
        longitude: CodegenTypes.Double,
        latitude: CodegenTypes.Double
    ]>;
    anchor?: NativeAnchor;
    offset?: NativeOffset;
    onPress?: CodegenTypes.BubblingEventHandler<NativeAnnotationEvent>;
    onSelect?: CodegenTypes.BubblingEventHandler<NativeAnnotationEvent>;
    onDeselect?: CodegenTypes.BubblingEventHandler<NativeAnnotationEvent>;
    onDragStart?: CodegenTypes.DirectEventHandler<NativeAnnotationEvent>;
    onDrag?: CodegenTypes.DirectEventHandler<NativeAnnotationEvent>;
    onDragEnd?: CodegenTypes.DirectEventHandler<NativeAnnotationEvent>;
}
interface NativeCommands {
    refresh: (viewRef: React.ElementRef<HostComponent<NativeProps>>) => void;
}
export declare const Commands: NativeCommands;
declare const _default: HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=PointAnnotationNativeComponent.d.ts.map