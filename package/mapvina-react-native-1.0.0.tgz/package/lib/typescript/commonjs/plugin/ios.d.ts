import { type ConfigPlugin } from "@expo/config-plugins";
import type { MapVinaPluginProps } from "./MapVinaPluginProps";
/**
 * Only the post-install block is required, the post installer block is used for
 * SPM (Swift Package Manager) which Expo doesn't currently support.
 */
export declare function applyPodfilePostInstall(contents: string): string;
export declare const applyPodfileGlobalVariables: (contents: string, props: MapVinaPluginProps) => string;
export declare const withPodfileGlobalVariables: ConfigPlugin<MapVinaPluginProps>;
export declare const ios: {
    withPodfilePostInstall: ConfigPlugin;
    withPodfileGlobalVariables: ConfigPlugin<MapVinaPluginProps>;
    withDwarfDsym: ConfigPlugin;
};
//# sourceMappingURL=ios.d.ts.map