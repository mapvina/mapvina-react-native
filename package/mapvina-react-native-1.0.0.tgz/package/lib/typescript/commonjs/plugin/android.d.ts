import { type ConfigPlugin } from "@expo/config-plugins";
import type { PropertiesItem } from "@expo/config-plugins/build/android/Properties";
import type { MapVinaPluginProps } from "./MapVinaPluginProps";
type PropertyItem = {
    type: "property";
    key: string;
    value: string;
};
export declare const GRADLE_PROPERTIES_PREFIX = "io.github.mapvina.reactnative.";
export declare const getGradleProperties: (props: MapVinaPluginProps) => PropertyItem[];
export declare const mergeGradleProperties: (oldProperties: PropertiesItem[], newProperties: PropertyItem[]) => PropertiesItem[];
export declare const withGradleProperties: ConfigPlugin<MapVinaPluginProps>;
export declare const android: {
    withGradleProperties: ConfigPlugin<MapVinaPluginProps>;
};
export {};
//# sourceMappingURL=android.d.ts.map