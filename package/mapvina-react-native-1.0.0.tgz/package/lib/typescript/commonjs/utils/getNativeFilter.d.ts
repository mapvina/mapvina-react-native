import type { FilterSpecification } from "@mapvina/mapvina-gl-style-spec";
export declare function getNativeFilter(filter: FilterSpecification | undefined): unknown[];
//# sourceMappingURL=getNativeFilter.d.ts.map